# google-map
This function shows the location of different users on Google Map, feel free to used, if any problem drop me a email.   gsalman950@gmail.com thanks 
